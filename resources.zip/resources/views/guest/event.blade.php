<x-guest-layout :seo="$seo">
 <x-guest.event :event="$event" />
</x-guest-layout>
